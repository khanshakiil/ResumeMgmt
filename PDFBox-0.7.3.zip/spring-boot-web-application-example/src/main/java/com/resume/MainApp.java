package com.resume;

import java.io.IOException;

import org.apache.lucene.queryParser.ParseException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class MainApp extends SpringBootServletInitializer {

	public static void main(String[] args) throws IOException, ParseException {
		SpringApplication.run(MainApp.class, args);
	}

}
