package com.resume.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.lucene.queryParser.ParseException;
import org.pdfbox.pdmodel.PDDocument;
import org.pdfbox.util.PDFTextStripper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.resume.IndexItem;
import com.resume.Indexer;
import com.resume.Searcher;

import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
@RequestMapping("/resume")
public class ResumeController {

	private static final String INDEX_DIR = "src/main/resources/index";
	private static final int DEFAULT_RESULT_SIZE = 100;

	@Value("${resume.storage.dir}")
	String resumeLocation;

	@GetMapping("/")
	public String resumeSearch() {
		return "resumeSearch";
	}

	@PostMapping("/search")
	public String search(@RequestParam("searchWord") String searchWord, Model model) {

		log.info("Searching CV for {} in {}", searchWord, resumeLocation);
		List<String> resumeList = searchResumes(resumeLocation, searchWord);
		model.addAttribute("resumeList", resumeList);
		model.addAttribute("searchWord", searchWord);

		if (resumeList.isEmpty())
			model.addAttribute("message", "No matching resume");
		log.info(resumeList);

		return "resumeSearch";
	}

	private List<String> searchResumes(String resumeLocation, String searchWord) {

		List resumeList = new ArrayList<>();
		File resumeDir = new File(resumeLocation);

		if (resumeDir.isDirectory()) {

			Arrays.asList(resumeDir.listFiles()).forEach(pdfFile -> {
				log.info(pdfFile.getName());
				// File pdfFile = new File("E:\\Documents\\Account Details.pdf");
				IndexItem pdfIndexItem;
				try {
					pdfIndexItem = index(pdfFile);

					// creating an instance of the indexer class and indexing the items
					Indexer indexer = new Indexer(INDEX_DIR);
					// System.out.println("content=" + pdfIndexItem.getContent());
					indexer.index(pdfIndexItem);

					indexer.close();

					// creating an instance of the Searcher class to the query the index
					Searcher searcher = new Searcher(INDEX_DIR);
					int result = searcher.findByContent(searchWord, DEFAULT_RESULT_SIZE);
					log.info("Result = {} ", result);
					if (result > 0) {
						resumeList.add(pdfFile.getName());
					}
					indexer.delete(INDEX_DIR);
					indexer.close();
					searcher.close();

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			});
		}
		return resumeList;
	}

	@GetMapping(value = "/download/{fileName}")
	public void downloadFile(HttpServletResponse response, @PathVariable("fileName") String fileName)
			throws IOException {

		File file = new File(resumeLocation, fileName);

		if (!file.exists()) {
			String errorMessage = "Sorry. The file you are looking for does not exist";
			System.out.println(errorMessage);
			OutputStream outputStream = response.getOutputStream();
			outputStream.write(errorMessage.getBytes(Charset.forName("UTF-8")));
			outputStream.close();
			return;
		}

		String mimeType = URLConnection.guessContentTypeFromName(file.getName());
		if (mimeType == null) {
			System.out.println("mimetype is not detectable, will take default");
			mimeType = "application/octet-stream";
		}

		System.out.println("mimetype : " + mimeType);

		response.setContentType(mimeType);

		/*
		 * "Content-Disposition : inline" will show viewable types [like
		 * images/text/pdf/anything viewable by browser] right on browser while
		 * others(zip e.g) will be directly downloaded [may provide save as popup, based
		 * on your browser setting.]
		 */
		response.setHeader("Content-Disposition", String.format("inline; filename=\"" + file.getName() + "\""));

		/*
		 * "Content-Disposition : attachment" will be directly download, may provide
		 * save as popup, based on your browser setting
		 */
		// response.setHeader("Content-Disposition", String.format("attachment;
		// filename=\"%s\"", file.getName()));

		response.setContentLength((int) file.length());

		InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

		// Copy bytes from source to destination(outputstream in this example), closes
		// both streams.
		FileCopyUtils.copy(inputStream, response.getOutputStream());
	}

// Extract text from PDF document
	public static IndexItem index(File file) throws IOException {
		log.info(file);
		PDDocument doc = PDDocument.load(file);
		String content = new PDFTextStripper().getText(doc);
		doc.close();
		return new IndexItem((long) file.getName().hashCode(), file.getName(), content);
	}
}
