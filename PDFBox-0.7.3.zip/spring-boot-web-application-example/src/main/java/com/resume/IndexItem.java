package com.resume;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class IndexItem {
	private Long id;
	private String title;
	private String content;

	public static final String ID = "id";
	public static final String TITLE = "title";
	public static final String CONTENT = "content";

}
